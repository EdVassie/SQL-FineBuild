-- Copyright FineBuild Team � 2016.  Distributed under Ms-Pl License
-- Code based on blog post from Mark Tassin.
-- http://cryptoknight.org/index.php?/archives/1-SSIS-Maintenance-Script.html
-- Some indexes suggested by Mark are now included by Microsoft, this file adds the remaining indexes.

-- Disable Lock Escalation on all tables to assist Cleanup process
DECLARE @SQL NVARCHAR(MAX);
SELECT
 @SQL = COALESCE(@SQL + N'ALTER TABLE [' + SCHEMA_NAME(schema_id) + N'].[' + name + N'] SET (LOCK_ESCALATION=DISABLE);','ALTER TABLE [' + SCHEMA_NAME(schema_id) + '].[' + name + '] SET (LOCK_ESCALATION=DISABLE);')
FROM sys.tables;
EXEC sp_executesql @SQL;

-- Add Indexes to assist Cleanup process

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[event_message_context]') AND name = N'IX_EventMessageContext_Event_Message_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_EventMessageContext_Event_Message_id] ON [internal].[event_message_context]
  (
	[event_message_id] ASC,
	[operation_id] ASC,
	[context_id] ASC
  )  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[event_messages]') AND name = N'IX_EventMessages_Operation_id2')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_EventMessages_Operation_id2] ON [internal].[event_messages]
  (
	[event_message_id] ASC,
	[operation_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[execution_component_phases]') AND name = N'IX_ExecutionComponentPhases_Execution_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExecutionComponentPhases_Execution_id] ON [internal].[execution_component_phases]
  (
	[execution_id] ASC,
	[phase_stats_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[execution_data_statistics]') AND name = N'IX_ExecutionDataStatistics_Execution_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExecutionDataStatistics_Execution_id] ON [internal].[execution_data_statistics]
  (
	[execution_id] ASC,
	[data_stats_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[execution_data_taps') AND name = N'IX_ExecutionDataTaps_Execution_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExecutionDataTaps_Execution_id] ON [internal].[execution_data_taps]
  (
	[execution_id] ASC,
	[data_tap_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[execution_parameter_values]') AND name = N'IX_ExecutionParameterValue_Execution_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExecutionParameterValue_Execution_id] ON [internal].[execution_parameter_values]
  (
	[execution_id] ASC,
	[execution_parameter_id] ASC
  )
  INCLUDE (
   	[object_type],
	[parameter_data_type],
	[parameter_name],
	[parameter_value],
	[sensitive_parameter_value],
	[base_data_type],
	[sensitive],
	[required],
	[value_set],
	[runtime_override]) 
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[execution_parameter_values]') AND name = N'IX_ExecutionParameterValue_Parameter_Name')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExecutionParameterValue_Parameter_Name] ON [internal].[execution_parameter_values]
  (
	[parameter_name] ASC,
	[execution_parameter_id] ASC
  )
  INCLUDE (
   	[execution_id],
	[object_type],
	[parameter_data_type],
	[parameter_value],
	[sensitive_parameter_value],
	[base_data_type],
	[sensitive],
	[required],
	[value_set],
	[runtime_override]) 
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[execution_property_override_values]') AND name = N'IX_ExecutionPropertyOverrideValues_Execution_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExecutionPropertyOverrideValues_Execution_id] ON [internal].[execution_property_override_values]
  (
	[execution_id] ASC,
	[property_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[extended_operation_info]') AND name = N'IX_ExtendedOperationInfo_Operation_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_ExtendedOperationInfo_Operation_id] ON [internal].[extended_operation_info]
  (
	[operation_id] ASC,
	[info_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[operation_os_sys_info]') AND name = N'IX_OperationsOsSysInfo_Operation_id_Info_id')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_OperationsOsSysInfo_Operation_id_Info_id] ON [internal].[operation_os_sys_info]
  (
	[operation_id] ASC,
	[info_id] ASC
  )
  INCLUDE (
	[total_physical_memory_kb],
	[available_physical_memory_kb],
	[total_page_file_kb],
	[available_page_file_kb],
	[cpu_count]) 
  WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[internal].[operations]') AND name = N'IX_operations_end_time')
  CREATE UNIQUE NONCLUSTERED INDEX [IX_operations_end_time] ON [internal].[operations]
  (
	[end_time] ASC,
	[created_time] ASC,
	[status] ASC,
	[operation_id] ASC
  ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ONLINE = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);

GO