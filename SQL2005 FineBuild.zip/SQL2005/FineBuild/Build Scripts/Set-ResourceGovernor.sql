-- Copyright FineBuild Team � 2016 - 2017.  Distributed under Ms-Pl License
USE [master]
GO
-- Get variable data
DECLARE
 @MaxDop                        varchar(4)
,@RPOptions                     varchar(100)
,@SQL                           Varchar(max)
,@SQLVersion                    Varchar(8);

SELECT
 @MaxDop			= CAST(value AS varchar(4))
,@RPOptions                     = ''
,@RPOptions                     = CASE WHEN CAST(SERVERPROPERTY('ProductVersion') AS CHAR(2)) >= '11' THEN @RPOptions + ',cap_cpu_percent=100,AFFINITY SCHEDULER = AUTO' ELSE @RPOptions END
,@RPOptions                     = CASE WHEN CAST(SERVERPROPERTY('ProductVersion') AS CHAR(2)) >= '12' THEN @RPOptions + ',min_iops_per_volume=0,max_iops_per_volume=0'   ELSE @RPOptions END
FROM sys.configurations
WHERE name = 'max degree of parallelism';

-- Setup Resource Governor Pools

IF CAST(SERVERPROPERTY('ProductVersion') AS CHAR(2)) >= '13'
  IF NOT EXISTS ( SELECT name FROM sys.resource_governor_external_resource_pools WHERE name = N'Analytics')
  BEGIN;
    SELECT @SQL = 
    'CREATE EXTERNAL RESOURCE POOL [Analytics]
      WITH(max_cpu_percent=100
	,max_memory_percent=100
	,AFFINITY CPU = AUTO
	,max_processes=0)';
  EXECUTE (@SQL);
  END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'Analytics')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [Analytics]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'AdHoc')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [AdHoc]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'Batch')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [Batch]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'DBA')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [DBA]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'OLTP')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [OLTP]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'Report')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [Report]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_resource_pools WHERE name = N'System')
BEGIN;
  SELECT @SQL = 
  'CREATE RESOURCE POOL [System]
     WITH(min_cpu_percent=0
	,max_cpu_percent=100
	,min_memory_percent=0
	,max_memory_percent=100'
	+ @RPOptions + ')';
  EXECUTE (@SQL);
END;

-- Setup Workload Groups

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'Analytics')
  BEGIN;
    SELECT @SQL = 
    'CREATE WORKLOAD GROUP [Analytics]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
    USING [Analytics]';
    IF CAST(SERVERPROPERTY('ProductVersion') AS CHAR(2)) >= '13'
      SELECT @SQL = @SQL + ', EXTERNAL [Analytics]';
    EXECUTE (@SQL);
  END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'AdHoc')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [AdHoc]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
    USING [AdHoc]';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'BatchDay')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [BatchDay]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
   USING [Batch]';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'BatchNight')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [BatchNight]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
   USING [Batch]';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'BatchDBMaint')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [BatchDBMaint]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
   USING [Batch]';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'DBA')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [DBA]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop=0)
    USING [DBA]';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'OLTP')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [OLTP]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
    USING [OLTP]';
  EXECUTE (@SQL);
END;

IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'Report')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [Report]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
   USING [Report]';
  EXECUTE (@SQL);
END;


IF NOT EXISTS ( SELECT name FROM sys.resource_governor_workload_groups WHERE name = N'System')
BEGIN;
  SELECT @SQL = 
  'CREATE WORKLOAD GROUP [System]
    WITH(group_max_requests=0
	,importance=Medium
	,request_max_cpu_time_sec=0
	,request_max_memory_grant_percent=25
	,request_memory_grant_timeout_sec=0
	,max_dop='+@MaxDop+')
   USING [System]';
  EXECUTE (@SQL);
END;

-- Setup Classifier Tables

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usr_ResourceGovernorClassifier]') AND type in (N'U'))
BEGIN;
  CREATE TABLE [dbo].[usr_ResourceGovernorClassifier]
  ([Id]                 [int] IDENTITY(1,1) NOT NULL
  ,[AppName]            [nvarchar](256) NULL
  ,[DBName]             [nvarchar](256) NULL
  ,[TimeStart]          [char](5) NOT NULL
  ,[TimeEnd]            [char](5) NOT NULL
  ,[WorkloadGroup]      [nvarchar](256) NOT NULL
    CONSTRAINT [PK_usr_ResourceGovernorClassifier] PRIMARY KEY CLUSTERED 
    ([Id] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON));
	
  CREATE UNIQUE INDEX [Idx_ResourceGovernorClassifier_Role_AppName_DBName] ON [dbo].[usr_ResourceGovernorClassifier]
  ([AppName] Desc,[DBName] Desc, [Id] Asc)
  INCLUDE([TimeStart], [TimeEnd], [WorkloadGroup]);
END;

-- Initial data load of Classifier table

TRUNCATE TABLE [dbo].[usr_ResourceGovernorClassifier];

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'Analytics')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'Analytics',NULL,'00:00','24:00','Analytics');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'AdHoc')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'AdHoc',NULL,'00:00','24:00','AdHoc');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'Batch' AND [WorkloadGroup] = N'BatchNight')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'Batch',NULL,'18:00','07:00','BatchNight');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'Batch' AND [WorkloadGroup] = N'BatchDay')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'Batch',NULL,'07:00','18:00','BatchDay');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'Batch' AND [WorkloadGroup] = N'BatchDBMaint')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'DBMaint',NULL,'00:00','24:00','BatchDBMaint');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'DBA')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES ('DBA',NULL,'00:00','24:00','DBA');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'OLTP')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'OLTP',NULL,'00:00','24:00','OLTP');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'Report')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'Report',NULL,'00:00','24:00','Report');

IF NOT EXISTS (SELECT 1 FROM [dbo].[usr_ResourceGovernorClassifier] WHERE [AppName] = N'System')
  INSERT INTO [dbo].[usr_ResourceGovernorClassifier]
    ([AppName],[DBName],[TimeStart],[TimeEnd],[WorkloadGroup])
    VALUES (N'System',NULL,'00:00','24:00','System');

-- Setup Classifier Function

ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = NULL);
ALTER RESOURCE GOVERNOR RECONFIGURE;

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[usrfn_ResourceGovernorClassifier]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
  DROP FUNCTION [dbo].[usrfn_ResourceGovernorClassifier];
GO
  CREATE FUNCTION [dbo].[usrfn_ResourceGovernorClassifier]()
  RETURNS SYSNAME
  WITH SCHEMABINDING
  AS
  BEGIN;
    DECLARE
     @AppNameBase       nvarchar(256)
    ,@AppName           nvarchar(256)
    ,@DBName            nvarchar(256)
    ,@RunTime           datetime
    ,@Time              Char(5)
    ,@WorkloadGroup     sysname;

    SELECT 
      @AppNameBase    = APP_NAME()
     ,@DBName         = ORIGINAL_DB_NAME()
     ,@AppName        = CASE WHEN @AppNameBase LIKE '.Net SqlClient%' THEN 'OLTP'
                             WHEN @AppNameBase LIKE 'RTerm.exe' THEN 'Analytics'
                             WHEN @AppNameBase LIKE 'BxlServer.exe' THEN 'Analytics'
                             WHEN @AppNameBase LIKE 'Microsoft R Host' THEN 'Analytics'
                             WHEN @AppNameBase LIKE 'RStudio%' THEN 'Analytics'
                             WHEN @AppNameBase LIKE 'Microsoft Office%' THEN 'AdHoc'
                             WHEN @AppNameBase LIKE 'SQLPS %' THEN 'AdHoc'
                             WHEN @AppNameBase LIKE 'Microsoft SQL Server Management Studio%' THEN 'AdHoc'
                             WHEN @AppNameBase LIKE 'Microsoft%Visual Studio%' THEN 'AdHoc'
                             WHEN @AppNameBase LIKE '%Print%' THEN 'Batch'
                             WHEN @AppNameBase LIKE 'SQLAgent%Jobstep%' AND @DBName = 'msdb' THEN 'System'
                             WHEN @AppNameBase LIKE 'SQLAgent%Jobstep%' THEN 'Batch'
                             WHEN @AppNameBase LIKE '%Report%' THEN 'Report'
                             WHEN @AppNameBase LIKE 'DQ Services%' THEN 'System'
                             WHEN @AppNameBase LIKE 'DatabaseMail%' THEN 'System'
                             WHEN @AppNameBase LIKE 'Microsoft%Windows%' THEN 'System'
                             WHEN @AppNameBase LIKE 'SQLAgent%' THEN 'System'
                             WHEN @AppNameBase LIKE 'SQL Server Data Collector%' THEN 'System'
                             ELSE @AppNameBase END
     ,@AppName        = CASE WHEN @AppName <> 'Adhoc' THEN @AppName
                             WHEN IS_SRVROLEMEMBER('sysadmin') = 1 THEN 'DBA'
                             ELSE @AppName END
     ,@RunTime        = Getdate()
     ,@Time           = Convert(Char(5), @Runtime, 14);

    SELECT TOP 1
      @WorkloadGroup = WorkloadGroup
    FROM [dbo].[usr_ResourceGovernorClassifier]
    WHERE (@AppName   = [AppName] OR [AppName] IS NULL)
      AND (@DBName    = [DBName]  OR [DBName] IS NULL)
      AND @Time      >= [TimeStart]
      AND @Time       < [TimeEnd]
    ORDER BY [AppName] Desc,[DBName] Desc;

   RETURN @WorkloadGroup;
 END;
 GO
-- Activate Resource Governor

ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = [dbo].[usrfn_ResourceGovernorClassifier]);
IF CAST(SERVERPROPERTY('ProductVersion') AS CHAR(2)) >= '12'
BEGIN;
  DECLARE
    @SQL                        Varchar(max);
  SELECT @SQL = 
  'ALTER RESOURCE GOVERNOR WITH (MAX_OUTSTANDING_IO_PER_VOLUME = DEFAULT);';
  EXECUTE (@SQL);
END;
ALTER RESOURCE GOVERNOR RECONFIGURE;
